<?php

include('database.php');


if(isset($_GET['edit'])){

    $id= $_GET['edit'];
  $editData= edit_data($connection, $id);
}

if(isset($_POST['update']) && isset($_GET['edit'])){

  $id= $_GET['edit'];
    update_data($connection,$id);
    
    
} 
function edit_data($connection, $id)
{
 $query= "SELECT * FROM Services WHERE id= $id";
 $exec = mysqli_query($connection, $query);
 $row= mysqli_fecth_assoc($exec);
 return $row;
}

function update_data($connection, $id){

    $Service= legal_input($_POST['service']);
      $description= legal_input($_POST['description']);
      $duration = legal_input($_POST['duration']);
      $cost = legal_input($_POST['cost']);

      $query="UPDATE Services 
            SET service='$service',
                description='$description',
                duration= '$duration'
                status='$status' WHERE id=$id";

      $exec= mysqli_query($connection,$query);
  
      if($exec){
         header('location:Services_table.php');
      
      }else{
         $msg= "Error: " . $query . "<br>" . mysqli_error($connection);
         echo $msg;  
      }
}

// convert illegal input to legal input
function legal_input($value) {
  $value = trim($value);
  $value = stripslashes($value);
  $value = htmlspecialchars($value);
  return $value;
}
?>